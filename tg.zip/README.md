# Telegram AIogram ChatGPT Bot

This project is a Telegram bot built using the Aiogram framework that collects user information, summarizes it using the ChatGPT API, and sends the summary to a specified recipient.

## Project Structure

```
telegram-aiogram-chatgpt-bot
├── src
│   ├── bot.py
│   ├── handlers
│   │   └── user_info.py
│   ├── services
│   │   └── chatgpt.py
│   └── config.py
├── requirements.txt
└── README.md
```

## Features

- Collects user information through interactive prompts.
- Summarizes the collected information using the ChatGPT API.
- Sends the summary to a designated recipient.

## Installation

1. Clone the repository:
   ```
   git clone <repository-url>
   cd telegram-aiogram-chatgpt-bot
   ```

2. Install the required dependencies:
   ```
   pip install -r requirements.txt
   ```

3. Set up your configuration in `src/config.py`:
   - Add your Telegram bot token.
   - Add your ChatGPT API key.

## Usage

1. Run the bot:
   ```
   python src/bot.py
   ```

2. Start a chat with the bot on Telegram and follow the prompts to provide your information.

## Contributing

Contributions are welcome! Please open an issue or submit a pull request for any improvements or bug fixes.

## License

This project is licensed under the MIT License. See the LICENSE file for details.