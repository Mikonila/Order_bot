import os
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN")
CHATGPT_API_KEY = os.getenv("CHATGPT_API_KEY")
LOG_CHAT_ID = -4805355986  # ID группы для логирования всех сообщений